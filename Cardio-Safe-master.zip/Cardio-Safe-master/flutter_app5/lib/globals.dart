library my_prj.globals;

var TempWarning = "";